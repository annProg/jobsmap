LBS云短租示例

文件目录结构
--js                  js文件的存放目录
----bootstrap.js
----bootstrap.min.js
----jquery.js
----jquery.pager.js   分页插件
----main.js           js主文件代码
--css                 css文件的存放目录
----bootstrap.css
----bootstrap.min.css
----main.css          主要的css样式文件
----index.html        html页面

使用到jquery、bootstrap框架搭建页面
jquery.pager  用来做分页组件

兼容PC端各主流浏览器，IE7以上
